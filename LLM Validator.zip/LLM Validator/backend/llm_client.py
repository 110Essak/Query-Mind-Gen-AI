from langchain_groq import ChatGroq
from langchain.schema import HumanMessage
from vector_db import search_context

def get_llm_response(query: str, report_content: str = None, original_text: str = None) -> str:
    """
    Fetches a response from Groq Cloud API using LangChain.
    
    - Uses `original_text` for summarization.
    - Uses `report_content` for report generation.
    - Otherwise, defaults to normal LLM query.
    """
    API_KEY = "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"  # Replace with your actual API key
    chat = ChatGroq(model_name="mixtral-8x7b-32768", groq_api_key=API_KEY)
    
    # Construct prompt
    if original_text:
        prompt = f"{query}\n\nOriginal text:\n{original_text}"
    elif report_content:
        prompt = f"{query}\n\nContent to base report on:\n{report_content}"
    else:
        context = search_context(query)
        prompt = f"{query}\n\nContext of previous chats similar to given query:\n{context}";

    try:
        response = chat.invoke([HumanMessage(content=prompt)])
        return response.content
    except Exception as e:
        return f"Error: {str(e)}"

